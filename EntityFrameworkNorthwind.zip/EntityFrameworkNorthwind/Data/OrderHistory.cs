﻿namespace EntityFrameworkNorthwind.Data
{
    public class OrderHistory
    {
        private OrderHistory() { }
        public int Total { get; private set; }
        public string ProductName { get; private set; }
    }
}
