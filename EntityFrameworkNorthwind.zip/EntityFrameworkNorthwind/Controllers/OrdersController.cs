﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EntityFrameworkNorthwind.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EntityFrameworkNorthwind.Controllers
{
    [Route("api/[controller]")]
    public class OrdersController : Controller
    {
        private readonly NorthwindContext _northwindContext;

        public OrdersController(NorthwindContext northwindContext)
        {
            _northwindContext = northwindContext;
        }

        [HttpGet("{orderId}")]
        public async Task<IActionResult> Get(int orderId)
        {
            var order = await _northwindContext.Orders.Where(o => o.OrderId == orderId).SingleOrDefaultAsync();
            return Ok(order);
        }
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var orders = await _northwindContext.Orders.ToListAsync();
            return Ok(orders);
        }

        [HttpGet("{customerId}/history")]
        public async Task<IActionResult> GetHistory(string customerId)
        {
            List<OrderHistory> orderHistoryList = await _northwindContext.OrderHistory.FromSqlRaw($"EXECUTE dbo.CustOrderHist {customerId}").ToListAsync();
            //List<OrderHistory> orderHistoryList = await _northwindContext.OrderHistory.FromSql("EXECUTE dbo.CustOrderHist {0}", customerId).ToListAsync();

            return Ok(orderHistoryList);
        }

    }
}
